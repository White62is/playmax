# Central de Links

Painel responsivo em React + Vite para organizar atalhos pessoais.

## Rodar localmente

1. Instale Node.js (versão 18 ou superior).
2. No terminal, dentro da pasta do projeto, execute `npm install`.
3. Execute `npm run dev` e abra o endereço mostrado no terminal.
4. Para gerar a versão de publicação, execute `npm run build`. A pasta gerada será `dist`.

## Publicar

- **Vercel:** importe o repositório Git. Framework: Vite; Build command: `npm run build`; Output directory: `dist`.
- **Netlify:** importe o repositório Git. Build command: `npm run build`; Publish directory: `dist`.

## Observação importante sobre dados e administração

Esta é a primeira versão de interface. Os links são salvos no `localStorage` do navegador atual. Isso significa que não sincronizam entre dispositivos e podem ser apagados se os dados do navegador forem removidos. O botão Administrar apenas ativa a edição local e NÃO é uma área protegida por senha. Antes de usar publicamente com dados importantes, conecte um banco de dados e autenticação (por exemplo, Supabase) para que só você possa administrar e os links sincronizem em todos os dispositivos.
