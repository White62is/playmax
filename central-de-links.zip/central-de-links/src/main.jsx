import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, Plus, Settings2, ExternalLink, Pencil, Trash2, X, Link2, LayoutGrid, ShieldCheck, Sparkles } from 'lucide-react';
import './style.css';

const starter = [
  { id: 1, title: 'Google', url: 'https://google.com', description: 'Pesquisa e ferramentas do Google', category: 'Ferramentas', logo: 'https://www.google.com/s2/favicons?domain=google.com&sz=128' },
  { id: 2, title: 'YouTube', url: 'https://youtube.com', description: 'Vídeos, canais e conteúdos', category: 'Entretenimento', logo: 'https://www.google.com/s2/favicons?domain=youtube.com&sz=128' },
  { id: 3, title: 'WhatsApp Web', url: 'https://web.whatsapp.com', description: 'Acesse suas conversas pelo navegador', category: 'Comunicação', logo: 'https://www.google.com/s2/favicons?domain=whatsapp.com&sz=128' },
  { id: 4, title: 'ChatGPT', url: 'https://chatgpt.com', description: 'Assistente de inteligência artificial', category: 'Ferramentas', logo: 'https://www.google.com/s2/favicons?domain=chatgpt.com&sz=128' },
  { id: 5, title: 'Canva', url: 'https://canva.com', description: 'Designs, artes e apresentações', category: 'Trabalho', logo: 'https://www.google.com/s2/favicons?domain=canva.com&sz=128' },
  { id: 6, title: 'Google Drive', url: 'https://drive.google.com', description: 'Arquivos e documentos na nuvem', category: 'Trabalho', logo: 'https://www.google.com/s2/favicons?domain=drive.google.com&sz=128' }
];
const readLinks = () => { try { const v = JSON.parse(localStorage.getItem('central-links-data')); return Array.isArray(v) ? v : starter; } catch { return starter; } };

function App() {
  const [links, setLinks] = useState(readLinks);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Todos');
  const [admin, setAdmin] = useState(false);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: '', url: '', description: '', category: 'Pessoal', logo: '' });
  const categories = useMemo(() => ['Todos', ...new Set(links.map(x => x.category).filter(Boolean))], [links]);
  const visible = links.filter(x => (category === 'Todos' || x.category === category) && `${x.title} ${x.description} ${x.category}`.toLowerCase().includes(query.toLowerCase()));
  const saveLinks = next => { setLinks(next); localStorage.setItem('central-links-data', JSON.stringify(next)); };
  const openNew = () => { setEditing(null); setForm({ title: '', url: 'https://', description: '', category: 'Pessoal', logo: '' }); setModal(true); };
  const openEdit = item => { setEditing(item.id); setForm({ title: item.title, url: item.url, description: item.description || '', category: item.category || 'Pessoal', logo: item.logo || '' }); setModal(true); };
  const submit = e => { e.preventDefault(); const item = { ...form, id: editing ?? Date.now(), title: form.title.trim(), url: form.url.trim(), category: form.category.trim() || 'Outros' }; if (!/^https?:\/\//i.test(item.url)) item.url = `https://${item.url}`; saveLinks(editing ? links.map(x => x.id === editing ? item : x) : [item, ...links]); setModal(false); };
  const remove = id => { if (confirm('Excluir este link da sua central?')) saveLinks(links.filter(x => x.id !== id)); };

  return <div className="app-shell">
    <header className="topbar"><a className="brand" href="#top"><span className="brand-mark"><Link2 size={21}/></span><span>Central <b>de Links</b></span></a><div className="top-actions"><span className="status"><i/> Seu espaço de acessos</span><button className={`admin-btn ${admin ? 'active' : ''}`} onClick={() => setAdmin(!admin)}><Settings2 size={16}/>{admin ? 'Sair da edição' : 'Administrar'}</button></div></header>
    <main id="top" className="main">
      <section className="hero"><div className="eyebrow"><Sparkles size={14}/> SEU PAINEL PESSOAL</div><h1>Tudo o que é importante,<br/><span>em um só lugar.</span></h1><p>Seus sites, ferramentas e acessos favoritos organizados para você.</p>
        <div className="search-wrap"><Search size={20}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Pesquisar um link, ferramenta ou categoria..."/><kbd>⌘ K</kbd></div>
      </section>
      <section className="content"><div className="section-head"><div><div className="section-kicker">BIBLIOTECA</div><h2>Seus acessos <span className="count">{links.length}</span></h2></div>{admin && <button className="add-btn" onClick={openNew}><Plus size={17}/> Adicionar link</button>}</div>
        <div className="filters"><div className="filter-icon"><LayoutGrid size={16}/></div>{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={`chip ${category === c ? 'selected' : ''}`}>{c}</button>)}</div>
        {visible.length ? <div className="link-grid">{visible.map(item => <article className="link-card" key={item.id}><a className="card-main" href={item.url} target="_blank" rel="noreferrer"><div className="card-top"><div className="logo-box">{item.logo ? <img src={item.logo} alt="" onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling.style.display = 'grid'; }}/>:null}<span className="fallback-logo">{item.title.slice(0,1).toUpperCase()}</span></div><span className="card-category">{item.category}</span><ExternalLink className="external" size={16}/></div><h3>{item.title}</h3><p>{item.description || 'Acesse este link rapidamente.'}</p></a>{admin && <div className="card-admin"><button title="Editar" onClick={() => openEdit(item)}><Pencil size={14}/></button><button title="Excluir" onClick={() => remove(item.id)}><Trash2 size={14}/></button></div>}</article>)}</div> : <div className="empty"><div className="empty-icon"><Search size={23}/></div><h3>Nenhum link encontrado</h3><p>Tente pesquisar por outro termo ou escolha uma categoria diferente.</p></div>}
        {admin && <div className="admin-note"><ShieldCheck size={17}/><span><b>Modo de edição ativo.</b> As alterações ficam salvas neste navegador.</span></div>}
      </section>
    </main>
    <footer><div className="footer-brand"><span className="brand-mark small"><Link2 size={15}/></span> Central de Links</div><span>Organização simples. Acesso rápido.</span><span className="footer-version">VERSÃO 1.0</span></footer>
    {modal && <div className="overlay" onMouseDown={e => { if (e.target === e.currentTarget) setModal(false); }}><form className="modal" onSubmit={submit}><div className="modal-head"><div><div className="section-kicker">GERENCIAR ACESSOS</div><h2>{editing ? 'Editar link' : 'Adicionar link'}</h2></div><button type="button" className="close" onClick={() => setModal(false)}><X size={19}/></button></div><label>Nome do link<input required autoFocus value={form.title} onChange={e => setForm({...form, title:e.target.value})} placeholder="Ex.: Meu painel"/></label><label>Endereço (URL)<input required type="text" value={form.url} onChange={e => setForm({...form, url:e.target.value})} placeholder="https://exemplo.com"/></label><label>Descrição<input value={form.description} onChange={e => setForm({...form, description:e.target.value})} placeholder="Para que serve este link?"/></label><div className="form-row"><label>Categoria<input value={form.category} onChange={e => setForm({...form, category:e.target.value})} placeholder="Ex.: Trabalho"/></label><label>URL do logotipo<input value={form.logo} onChange={e => setForm({...form, logo:e.target.value})} placeholder="https://... (opcional)"/></label></div><div className="modal-actions"><button type="button" className="cancel-btn" onClick={() => setModal(false)}>Cancelar</button><button className="save-btn" type="submit">{editing ? 'Salvar alterações' : 'Adicionar à central'}</button></div></form></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
